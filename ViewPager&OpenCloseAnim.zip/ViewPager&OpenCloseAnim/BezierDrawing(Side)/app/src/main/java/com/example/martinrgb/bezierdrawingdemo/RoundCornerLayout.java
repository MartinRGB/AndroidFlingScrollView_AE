package com.example.martinrgb.bezierdrawingdemo;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class RoundCornerLayout extends RelativeLayout {

    public RoundCornerLayout(Context context) {
        super(context);
    }

    public RoundCornerLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RoundCornerLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
    }



    private Path mPath;
    public float SKETCH_ROUND_RECT_RADIUS = 36f;
    private float mCenterX = 0;
    private float mCenterY = 0;
    private boolean isOpened;



    @Override
    public void draw(Canvas canvas) {
        canvas.save();
        canvas.clipPath(mPath);
        super.draw(canvas);
        canvas.restore();
    }

    @Override
    public void dispatchDraw(Canvas canvas) {
//        canvas.save();
//        canvas.clipPath(mPath);
//        super.draw(canvas);
//        canvas.restore();

        int save = canvas.save();
        canvas.clipPath(mPath);
        super.dispatchDraw(canvas);
        canvas.restoreToCount(save);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        RectF r = new RectF(0, 0, w, h);
        mCenterX = w * 1.0f / 2;
        mCenterY = h * 1.0f / 2;
        mPath = new Path();
        mPath.addRoundRect(r, getCornerRadius(), getCornerRadius(), Path.Direction.CW);

        // #### Smooth Round Corner
//        if(SKETCH_ROUND_RECT_RADIUS == Math.min(w,h)/2){
//            mPath.addRoundRect(r, SKETCH_ROUND_RECT_RADIUS, SKETCH_ROUND_RECT_RADIUS, Path.Direction.CW);
//        }
//        else{
//            mPath = SketchRealSmoothRect(0, 0, w , h , SKETCH_ROUND_RECT_RADIUS,SKETCH_ROUND_RECT_RADIUS,
//                    true,true,true,true);
//        }
        mPath.close();
    }

    public boolean isOpened() {
        return isOpened;
    }

    public void setOpened(boolean opened) {
        isOpened = opened;
    }

    public void setCornerRadius(float radius) {
        SKETCH_ROUND_RECT_RADIUS = radius;
        invalidate();
    }

    public void setCornerRadiusWithoutInvalidate(float radius) {
        SKETCH_ROUND_RECT_RADIUS = radius;
    }

    public float getCornerRadius() {
        return SKETCH_ROUND_RECT_RADIUS;
    }

    public Path SketchRealSmoothRect(
            float left, float top, float right, float bottom, float rx, float ry,
            boolean tl, boolean tr, boolean bl, boolean br
    ){

        Path path = new Path();
        if (rx < 0) rx = 0;
        if (ry < 0) ry = 0;
        float width = right - left;
        float height = bottom - top;
        float posX = mCenterX - width/2;
        float posY = mCenterY - height/2;

        float r = rx;

        float vertexRatio;
        if(r/Math.min(width/2,height/2) > 0.5){
            float percentage = ((r/Math.min(width/2,height/2)) - 0.5f)/0.4f;
            float clampedPer = Math.min(1,percentage);
            vertexRatio = 1.f - (1 - 1.104f/1.2819f)*clampedPer;
        }
        else{
            vertexRatio = 1.f;
        }

        float controlRatio;
        if(r/Math.min(width/2,height/2) > 0.6){
            float percentage = ((r/Math.min(width/2,height/2)) - 0.6f)/0.3f;
            float clampedPer = Math.min(1,percentage);
            controlRatio = 1 + (0.8717f/0.8362f - 1)*clampedPer;
        }
        else{
            controlRatio = 1;
        }

        path.moveTo(posX + width/2 , posY);
        if(!tr){
            path.lineTo(posX + width, posY);
        }
        else{

            path.lineTo(posX + Math.max(width/2,width - r/100.0f*128.19f*vertexRatio), posY);
            path.cubicTo(posX + width - r/100.f*83.62f*controlRatio, posY,posX + width - r/100.f*67.45f,posY + r/100.f*4.64f, posX + width - r/100.f*51.16f, posY + r/100.f*13.36f);
            path.cubicTo(posX + width - r/100.f*34.86f, posY + r/100.f*22.07f,posX + width - r/100.f*22.07f,posY + r/100.f*34.86f, posX + width - r/100.f*13.36f, posY + r/100.f*51.16f);
            path.cubicTo(posX + width - r/100.f*4.64f, posY + r/100.f*67.45f,posX + width,posY + r/100.f*83.62f*controlRatio, posX + width, posY + Math.min(height/2,r/100.f*128.19f*vertexRatio));
        }


        if(!br){
            path.lineTo(posX + width, posY + height);
        }
        else{
            path.lineTo(posX + width, posY + Math.max(height/2,height - r/100.f*128.19f*vertexRatio));
            path.cubicTo(posX + width, posY + height - r/100.f*83.62f*controlRatio,posX + width - r/100.f*4.64f,posY + height - r/100.f*67.45f, posX + width - r/100.f*13.36f, posY + height -  r/100.f*51.16f);
            path.cubicTo(posX + width - r/100.f*22.07f, posY + height - r/100.f*34.86f,posX + width - r/100.f*34.86f,posY + height - r/100.f*22.07f, posX + width - r/100.f*51.16f, posY + height - r/100.f*13.36f);
            path.cubicTo(posX + width - r/100.f*67.45f, posY + height - r/100.f*4.64f,posX + width - r/100.f*83.62f*controlRatio,posY + height, posX + Math.max(width/2,width - r/100.f*128.19f*vertexRatio), posY + height);

        }


        if(!bl){
            path.lineTo(posX, posY + height);
        }
        else{
            path.lineTo(posX + Math.min(width/2,r/100.f*128.19f*vertexRatio), posY + height);
            path.cubicTo(posX +  r/100.f*83.62f*controlRatio, posY + height,posX + r/100.f*67.45f,posY + height - r/100.f*4.64f, posX + r/100.f*51.16f, posY + height -  r/100.f*13.36f);
            path.cubicTo(posX +  r/100.f*34.86f, posY + height - r/100.f*22.07f,posX + r/100.f*22.07f,posY + height - r/100.f*34.86f, posX + r/100.f*13.36f, posY + height - r/100.f*51.16f);
            path.cubicTo(posX  + r/100.f*4.64f, posY + height - r/100.f*67.45f,posX ,posY + height - r/100.f*83.62f*controlRatio, posX , posY + Math.max(height/2,height - r/100.f*128.19f*vertexRatio));

        }

        if(!tl){
            path.lineTo(posX, posY);
        }
        else{
            path.lineTo(posX, posY + Math.min(height/2,r/100.f*128.19f*vertexRatio));
            path.cubicTo(posX, posY + r/100.f*83.62f*controlRatio,posX + r/100.f*4.64f,posY + r/100.f*67.45f, posX + r/100.f*13.36f, posY + r/100.f*51.16f);
            path.cubicTo(posX +  r/100.f*22.07f, posY + r/100.f*34.86f,posX + r/100.f*34.86f,posY +  r/100.f*22.07f, posX + r/100.f*51.16f, posY + r/100.f*13.36f);
            path.cubicTo(posX  + r/100.f*67.45f, posY +  r/100.f*4.64f,posX + r/100.f*83.62f*controlRatio,posY, posX + Math.min(width/2,r/100.f*128.19f*vertexRatio), posY);

        }



        path.close();

        return path;
    }


    public float getMAXRadius(float width,float height){
        float minBorder;
        if(width > height){
            minBorder = height;
        }
        else{
            minBorder = width;
        }
        return minBorder/2.f;
    }
    private float getRadiusInMaxRange(float width,float height,float radius){
        float realRadius = Math.min(radius,getMAXRadius(width,height));
        return realRadius;
    }
}
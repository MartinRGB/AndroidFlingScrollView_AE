package com.example.martinrgb.bezierdrawingdemo;

import androidx.dynamicanimation.animation.DynamicAnimation.OnAnimationEndListener;
import androidx.dynamicanimation.animation.FlingAnimation;
import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;

public class FlingSpringAnim {

    private static  float FLING_FRICTION = 12f;
    private static  float SPRING_STIFFNESS = 400;
    private static  float SPRING_DAMPING = 0.8f;

    private final FlingAnimation mFlingAnim;
    private SpringAnimation mSpringAnim;

    private float mTargetPosition;

    public <K> FlingSpringAnim(K object, FloatPropertyCompat<K> property, float startPosition,
            float targetPosition, float startVelocity, float minVisChange, float minValue,
            float maxValue, float springVelocityFactor, OnAnimationEndListener onEndListener) {
        mFlingAnim = new FlingAnimation(object, property)
                .setFriction(FLING_FRICTION)
                // Have the spring pull towards the target if we've slowed down too much before
                // reaching it.
                .setMinimumVisibleChange(minVisChange)
                .setStartVelocity(startVelocity)
                .setMinValue(minValue)
                .setMaxValue(maxValue);
        mTargetPosition = targetPosition;

        mFlingAnim.addEndListener(((animation, canceled, value, velocity) -> {
            mSpringAnim = new SpringAnimation(object, property)
                    .setStartValue(value)
                    .setStartVelocity(velocity * springVelocityFactor)
                    .setSpring(new SpringForce(mTargetPosition)
                            .setStiffness(SPRING_STIFFNESS)
                            .setDampingRatio(SPRING_DAMPING));
            mSpringAnim.addEndListener(onEndListener);
            mSpringAnim.animateToFinalPosition(mTargetPosition);
        }));
    }

    public float getTargetPosition() {
        return mTargetPosition;
    }

    public void updatePosition(float startPosition, float targetPosition) {
        mFlingAnim.setMinValue(Math.min(startPosition, targetPosition))
                .setMaxValue(Math.max(startPosition, targetPosition));
        mTargetPosition = targetPosition;
        if (mSpringAnim != null) {
            mSpringAnim.animateToFinalPosition(mTargetPosition);
        }
    }

    public void start() {
        mFlingAnim.start();
    }

    public void end() {
        mFlingAnim.cancel();
        if (mSpringAnim.canSkipToEnd()) {
            mSpringAnim.skipToEnd();
        }
    }


    public  void setFlingFriction(float flingFriction) {
        FLING_FRICTION = flingFriction;
    }

    public  void setSpringStiffness(float springStiffness) {
        SPRING_STIFFNESS = springStiffness;
    }

    public  void setSpringDamping(float springDamping) {
        SPRING_DAMPING = springDamping;
    }

}

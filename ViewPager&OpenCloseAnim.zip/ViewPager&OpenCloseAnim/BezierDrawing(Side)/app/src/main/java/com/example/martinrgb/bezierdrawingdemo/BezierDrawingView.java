package com.example.martinrgb.bezierdrawingdemo;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.facebook.rebound.SimpleSpringListener;
import com.facebook.rebound.Spring;
import com.facebook.rebound.SpringConfig;
import com.facebook.rebound.SpringSystem;

import java.util.Random;

public class BezierDrawingView extends View {

    private Paint mPaint;
    private float vHeight = 2340;
    private PointF kGesturePoint = new PointF(0.f,-100.f);
    private int kColor = Color.BLACK;

    //##### Method Switcher
    private boolean setEffectIsClamped = true;

    //##### Method I
    //### 中心点 控制点 Y 轴位置
    private float kControlPointDistanceY = 130.f;
    //### 上下点 Y 轴位置
    private float kExtendedEdgesOffset = 20.f;
    //### 上下点 控制点 Y 偏移量
    private float kControlPointRatio = 0.6f;

    //##### Method II
    //### 滚动起始点
    private float kScrollMinInY = 0 - 1000; //936
    //### 滚动结束点
    private float kScrollMaxInY = 2340 + 1000;
    //### 滚动范围中心点
    private float kScrollRangeCenter;
    //### 中心点 X 轴最大范围
    private float kMaxControlPointPositionX = 120.f;
    //### 上下点 控制点 Y 轴位置
    private float kEdgePointDistanceY = 150.f;
    //### 30 - 0 | 70 - 100 缩小
    private float kDecayThereShold = 70.f;

    private boolean startDraw = false;

    private Handler handler;
    private Runnable runnable;
    private float randomX,randomY;
    private float lastMoveX,lastMoveY;
    private boolean isIncrease = true;

    private static final SpringConfig mconfig = SpringConfig.fromOrigamiTensionAndFriction(20, 20);
    private SpringSystem mSpringSystem;
    private Spring mSpringX,mSpringY;

    public BezierDrawingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        mPaint = new Paint();
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeWidth(12);
        mPaint.setColor(kColor);
        mPaint.setAntiAlias(true);
        setSpringSystem();
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {

                long ns = System.nanoTime();
                if (startDraw) {

                    //Do one frame of work
                    randomX = new Random().nextFloat();
                    randomY = new Random().nextFloat() * 2 -1;
//                    mSpringX.setEndValue(randomX);
//                    mSpringY.setEndValue(randomY);

                    if(isIncrease){
                        lastMoveY += 0.2;
                    }
                    else{
                        lastMoveY -= 0.1;
                    }

                    if(lastMoveY < 0){
                        isIncrease = true;
                    }
                    if(lastMoveY > 80){
                        isIncrease = false;
                    }
                    postInvalidate();
                    //Log.e("randomX",String.valueOf(randomX));
                    //Log.e("randomY",String.valueOf(randomY));
                    handler.post(runnable);

                }
            }
        };
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        vHeight = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        PointF gesturePoint = clampControlPointPositionX(kGesturePoint);
        float edgeOffsetVal;
        if(!setEffectIsClamped){
            edgeOffsetVal = kExtendedEdgesOffset;
        }
        else {
            //edgeOffsetVal = getScrollRangeCenter(kScrollMaxInY - kScrollMinInY)/2;
            edgeOffsetVal = 423;
        }
        Path path = BezierDrawingPath(gesturePoint,vHeight,kScrollMinInY,kScrollMaxInY,edgeOffsetVal,kControlPointRatio,kControlPointDistanceY,kEdgePointDistanceY);
        canvas.drawPath(path, mPaint);
    }

    public Path BezierDrawingPath(PointF point, float height,float scrollMin,float scrollMax,float edgeOffset,float ratio,float controlPointDistance,float edgePointDistance){
        Path path = new Path();

        if(!setEffectIsClamped){
            path.moveTo(0, - edgeOffset);
            addCurveToPoint(path,point,new PointF(0,point.y*ratio),new PointF(point.x,point.y - controlPointDistance));
            addCurveToPoint(path,new PointF(0,height + edgeOffset),new PointF(point.x,point.y + controlPointDistance),new PointF(0,point.y + (height - point.y)*(1 - ratio)));
        }
        else {
            float progress = (point.y - scrollMin)/(scrollMax - scrollMin)*100.f;
            PointF centerPoint = point;
            if(progress < 100 - kDecayThereShold){
                centerPoint.x = progress/(100.f - kDecayThereShold) * centerPoint.x ;
            }
            else if (progress > kDecayThereShold){
                centerPoint.x = Math.abs(progress - 100.f)/(100.f -kDecayThereShold) * centerPoint.x ;
            }
            else{
                centerPoint.x += lastMoveY/4.;
            }

            float pointTopY = centerPoint.y - edgeOffset;
            float pointBottomY = centerPoint.y + edgeOffset ;

            path.moveTo(-lastMoveY/4.f,pointTopY - lastMoveY);
            addCurveToPoint(path,centerPoint,new PointF(-lastMoveY/4.f ,centerPoint.y - edgePointDistance   ),new PointF(centerPoint.x
                    ,centerPoint.y-centerPoint.x/kMaxControlPointPositionX*controlPointDistance - lastMoveY/4.f));
            addCurveToPoint(path,new PointF(-lastMoveY/4.f ,pointBottomY + lastMoveY),new PointF(centerPoint.x  ,centerPoint.y + centerPoint.x/kMaxControlPointPositionX*controlPointDistance +lastMoveY/4),new PointF(0  ,centerPoint.y + edgePointDistance));
            path.close();

        }

        return path;
    }

    private PointF clampControlPointPositionX(PointF gesturePoint){
        return new PointF(Math.min(kMaxControlPointPositionX,gesturePoint.x),gesturePoint.y);
    };

    private void addCurveToPoint(Path path,PointF gesturePoint,PointF control_1_point,PointF control_2_point){
        path.cubicTo(control_1_point.x, control_1_point.y,control_2_point.x,control_2_point.y,gesturePoint.x, gesturePoint.y);
    }

    private float getScrollRangeCenter(float maxScrollRange){
        kScrollRangeCenter = maxScrollRange/2;
        return kScrollRangeCenter;
    }

    // ### Setter & Getter
    public float getViewHeight() {
        return vHeight;
    }

    public PointF getGesturePoint() {
        return kGesturePoint;
    }

    public float getControlPointRatio() {
        return kControlPointRatio;
    }

    public float getControlPointPulledDistance() {
        return kControlPointDistanceY;
    }

    public float getExtendedEdgesOffset() {
        return kExtendedEdgesOffset;
    }

    public float getkMaxControlPointPositionX() {
        return kMaxControlPointPositionX;
    }

    public int getColor() {
        return kColor;
    }

    public boolean isSetEffectIsClamped() {
        return setEffectIsClamped;
    }

    public void setViewHeight(float vHeight) {
        this.vHeight = vHeight;
        //postInvalidate();
    }

    public void setCurrentGesturePoint(PointF kGesturePoint) {
        this.kGesturePoint = kGesturePoint;
    }

    public void setGesturePoint(PointF kGesturePoint) {
        this.kGesturePoint = kGesturePoint;
        postInvalidate();
    }

    public void setControlPointRatio(float kControlPointRatio) {
        this.kControlPointRatio = kControlPointRatio;
        //postInvalidate();
    }

    public void setControlPointPulledDistance(float kControlPointPulledDistanceY) {
        this.kControlPointDistanceY = kControlPointPulledDistanceY;
        //postInvalidate();
    }

    public void setExtendedEdgesOffset(float kExtendedEdgesOffset) {
        this.kExtendedEdgesOffset = kExtendedEdgesOffset;
        //postInvalidate();
    }

    public void setkMaxControlPointPositionX(float kMaxControlPointPositionX) {
        this.kMaxControlPointPositionX = kMaxControlPointPositionX;
        //postInvalidate();
    }

    public void setColor(int kColor) {
        this.kColor = kColor;
        postInvalidate();
    }

    public void setSetEffectIsClamped(boolean setEffectIsClamped) {
        this.setEffectIsClamped = setEffectIsClamped;
    }

    public void setkScrollMinInY(float kScrollMinInY) {
        this.kScrollMinInY = kScrollMinInY;
    }

    public void setkScrollMaxInY(float kScrollMaxInY) {
        this.kScrollMaxInY = kScrollMaxInY;
    }


    public void startRandomAnimation(){
        startDraw = true;
        handler = new Handler();
        handler.post(runnable);
    }

    public void stopRandomAnimation(){
        startDraw = false;
        lastMoveX = lastMoveY = 0;
        handler.removeCallbacks(runnable);
    }

    private void setSpringSystem() {
        mSpringSystem = SpringSystem.create();
        mSpringX = mSpringSystem.createSpring();
        mSpringX.setSpringConfig(mconfig);
        mSpringX.addListener(new SimpleSpringListener() {
            @Override
            public void onSpringUpdate(Spring mSpring) {
                float progressVal = (float) mSpring.getCurrentValue();
                lastMoveX = progressVal;
            }
        });

        mSpringY = mSpringSystem.createSpring();
        mSpringY.setSpringConfig(mconfig);
        mSpringY.addListener(new SimpleSpringListener() {
            @Override
            public void onSpringUpdate(Spring mSpring) {
                float progressVal = (float) mSpring.getCurrentValue();
                lastMoveY = progressVal;
            }
        });

    }
}
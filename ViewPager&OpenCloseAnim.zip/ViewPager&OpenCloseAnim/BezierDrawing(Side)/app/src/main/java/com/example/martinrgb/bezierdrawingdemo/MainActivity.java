package com.example.martinrgb.bezierdrawingdemo;

import android.annotation.SuppressLint;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.interpolator.view.animation.FastOutLinearInInterpolator;

import com.facebook.rebound.SimpleSpringListener;
import com.facebook.rebound.Spring;
import com.facebook.rebound.SpringConfig;
import com.facebook.rebound.SpringSystem;
import com.facebook.rebound.SpringUtil;
import com.martinrgb.animer.Animer;
import com.martinrgb.animer.core.util.AnUtil;
import com.martinrgb.animer.monitor.AnConfigRegistry;
import com.martinrgb.animer.monitor.AnConfigView;
//import com.xw.repo.BubbleSeekBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private BezierDrawingView bezierDrawingView;
    private static final SpringConfig mconfig = SpringConfig.fromBouncinessAndSpeed(5, 20);
    private SpringSystem mSpringSystem;
    private Spring mSpringX,mSpringY;
    private PointF movePointF = new PointF (0.f,0.f);
    private boolean isVibrate = false;

    private RelativeLayout iconContainer;
    private ArrayList<View> viewList = new ArrayList<View>();
    private VelocityTracker mVelocityTracker;
    private static int[] icons = {
            R.drawable.icon_0, R.drawable.icon_1, R.drawable.icon_2, R.drawable.icon_3,
            R.drawable.icon_4, R.drawable.icon_5, R.drawable.icon_6, R.drawable.icon_7,
            R.drawable.icon_8, R.drawable.icon_9, R.drawable.icon_10, R.drawable.icon_11,
            R.drawable.icon_12, R.drawable.icon_13, R.drawable.icon_14, R.drawable.icon_15,
            R.drawable.icon_16, R.drawable.icon_17, R.drawable.icon_22,R.drawable.icon_23,
            R.drawable.icon_18, R.drawable.icon_19,
            R.drawable.icon_20, R.drawable.icon_21
    };
    private static  int[] apps ={
            R.drawable.app_1,R.drawable.app_0,R.drawable.app_2,R.drawable.app_3
    };

    private float startX,dampingMove;

    private AnConfigView mSpringConfiguratorView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        deleteBars();
        setContentView(R.layout.activity_main);
        iconContainer = findViewById(R.id.icon_container);
        initBezierView();
        setSpringSystem();
        initAnimer();
        createView();
        //initAnimer();
        setRangeSeekbar();


    }

    private Animer animerIconScale,animerX,animerY,animerIconX,animerIconY,animerIconGraphs,animerGridScale,animerAlpha,animerOpen,animerClosed;
    private void initAnimer(){

        mSpringConfiguratorView = (AnConfigView) findViewById(R.id.an_configurator);

        animerIconScale = new Animer();
        boolean scaleisFinished = false;
        animerIconScale.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerIconScale.setSolver(Animer.springDroid(700,0.88f));
        animerX = new Animer();
        animerX.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerX.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));
        animerY = new Animer();
        animerY.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerY.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));
        animerIconX = new Animer();
        animerIconX.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerIconX.setSolver(Animer.springDroid(CloseStiffness,Math.max(0.01f,CloseDampingRatio-parallaxDamping)));
        animerIconY = new Animer();
        animerIconY.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerIconY.setSolver(Animer.springDroid(CloseStiffness,Math.max(0.01f,CloseDampingRatio-parallaxDamping)));
        animerIconGraphs = new Animer();
        animerIconGraphs.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerIconGraphs.setSolver(Animer.springDroid(CloseStiffness,0.9f));
        animerGridScale = new Animer();
        animerGridScale.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerGridScale.setSolver(Animer.springDroid(200,0.92f));
        animerAlpha = new Animer();
        animerAlpha.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_ALPHA);
        animerAlpha.setSolver(Animer.springDroid(200,0.92f));
        animerOpen = new Animer();
        animerOpen.setFrom(0);
        animerOpen.setTo(1);
        animerOpen.setSolver(Animer.springDroid(OpenStiffnes,OpenDampingRatio));
        animerOpen.setMinimumVisibleChange(0.002f);
        animerClosed = new Animer();
        animerClosed.setFrom(0);
        animerClosed.setTo(1);
        animerClosed.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
        animerClosed.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));

        AnConfigRegistry.getInstance().addAnimer("打开 - 缩放",animerIconScale);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 图标 X 位移",animerX);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 图标 Y 位移",animerY);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 图标内缩放",animerIconGraphs);
        AnConfigRegistry.getInstance().addAnimer("关闭 - Workspace 缩放",animerGridScale);
        AnConfigRegistry.getInstance().addAnimer("关闭 - Workspace 不透明度",animerAlpha);
        AnConfigRegistry.getInstance().addAnimer("打开 - 位移",animerOpen);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 整体（弃）",animerClosed);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 图标内 X 位移（弃）",animerIconX);
        AnConfigRegistry.getInstance().addAnimer("关闭 - 图标内 Y 位移（弃）",animerIconY);

        mSpringConfiguratorView.refreshAnimerConfigs();
    }

    private void createView(){

        int id = 0;

        for (int i = 0; i < 32; i++) {

            if(i<20 && i>=0){

                createViewByIndex(i,id,0);
                id++;
            }
            else if(i<32 && i > 27){

                createViewByIndex(i,id,108);
                id++;

            }

        }
        findViewById(R.id.total_mask).setTranslationZ(50);
    }

    @SuppressLint("ClickableViewAccessibility")


    private float OpenStiffnes = 500,OpenDampingRatio = 0.8f,CloseStiffness = 400,CloseDampingRatio = 0.8f;
    private float finalX,finalY;
//    private RoundCornerLayout rv;
//    private ImageView app,icon,store,game,wechat,setting,phone,message,browser,camera;
    private static final float parallaxDamping = 0.10f;

    @SuppressLint("ClickableViewAccessibility")
    private void createViewByIndex(int i,int id,float bottomFix){

        final int finalStartX = 93;
        final int finalStartY = 150;
        final int index = i;
        final float bottomValue = bottomFix;

        RoundCornerLayout rv = new RoundCornerLayout(getApplicationContext());
        //rv.setBackgroundColor(Color.WHITE);
        RelativeLayout.LayoutParams rvParamas=new RelativeLayout.LayoutParams(156  , 156);
        rv.setLayoutParams(rvParamas);
        viewList.add(rv);
        rv.setId(id);
        iconContainer.addView(rv);
        rv.setTranslationX(finalStartX + (index%4)*246);
        rv.setTranslationY(finalStartY + (int)Math.ceil(index/4)*291 - bottomValue);
        rv.setClipChildren(true);

        final ImageView app = new ImageView((getApplicationContext()));
        RelativeLayout.LayoutParams appParams =new RelativeLayout.LayoutParams(156, 338);
        app.setLayoutParams(appParams);
        app.setImageResource(apps[id%4]);
        app.setScaleType(ImageView.ScaleType.FIT_XY);
        app.setAlpha(0f);
        //app.setVisibility(View.INVISIBLE);

        app.setId(id + 1000);
        rv.addView(app);


        final ImageView icon = new ImageView((getApplicationContext()));
        RelativeLayout.LayoutParams ivParams =new RelativeLayout.LayoutParams(156, 156);
        icon.setLayoutParams(ivParams);
        icon.setId(id + 2000);
        icon.setBackgroundResource(icons[id]);
        rv.addView(icon);
        rv.setOpened(false);


        RelativeLayout.LayoutParams iconParams =new RelativeLayout.LayoutParams(156, 156);
        final ImageView store = new ImageView((getApplicationContext()));

        if(i == 0){
            store.setLayoutParams(iconParams);
            store.setBackgroundResource(R.drawable.store_0);
            rv.addView(store);
        }

        final ImageView game = new ImageView((getApplicationContext()));
        if(i == 1){

            game.setLayoutParams(iconParams);
            game.setBackgroundResource(R.drawable.game_0);
            rv.addView(game);
        }


        final ImageView wechat = new ImageView((getApplicationContext()));


        if(i == 18){
            wechat.setLayoutParams(iconParams);
            wechat.setBackgroundResource(R.drawable.wechat_0);
            rv.addView(wechat);
        }

        final ImageView setting = new ImageView((getApplicationContext()));

        if(i == 19){
            setting.setLayoutParams(iconParams);
            setting.setBackgroundResource(R.drawable.setting_0);
            rv.addView(setting);
        }

        final ImageView phone = new ImageView((getApplicationContext()));

        if(i == 28){
            phone.setLayoutParams(iconParams);
            phone.setBackgroundResource(R.drawable.phone_0);
            rv.addView(phone);
        }

        final ImageView message = new ImageView((getApplicationContext()));

        if(i == 29){
            message.setLayoutParams(iconParams);
            message.setBackgroundResource(R.drawable.message_0);
            rv.addView(message);
        }

        final ImageView browser = new ImageView((getApplicationContext()));

        if(i == 30){
            browser.setLayoutParams(iconParams);
            browser.setBackgroundResource(R.drawable.browser_0);
            rv.addView(browser);
        }

        final ImageView camera = new ImageView((getApplicationContext()));

        if(i == 31){
            camera.setLayoutParams(iconParams);
            camera.setBackgroundResource(R.drawable.camera_0);
            rv.addView(camera);
        }

//        Animer animerIconScale = new Animer();
//        boolean scaleisFinished = false;
//        animerIconScale.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//        animerIconScale.setSolver(Animer.springDroid(700,0.88f));


//        animerIconScale.setUpdateListener(new Animer.UpdateListener() {
//            @Override
//            public void onUpdate(float value, float velocity, float progress) {
//                rv.setScaleX(value);
//                rv.setScaleY(value);
//                rv.setPivotX(156/2);
//                rv.setPivotY(156/2);
//            }
//        });
//
//        animerIconScale.setCurrentValue(1);

        View.OnTouchListener touchContainer = new View.OnTouchListener(){

            final View.OnTouchListener mTouchListener = this;

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        animerIconScale.setUpdateListener(new Animer.UpdateListener() {
                            @Override
                            public void onUpdate(float value, float velocity, float progress) {
                                view.setScaleX(value);
                                view.setScaleY(value);
                                view.setPivotX(156/2);
                                view.setPivotY(156/2);
                            }
                        });

                        animerIconScale.setCurrentValue(1);
                        animerIconScale.setEndvalue(0.83f);
                        break;
                    case MotionEvent.ACTION_MOVE:

                        break;
                    case MotionEvent.ACTION_UP:
                        animerIconScale.setEndvalue(1f);


                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {

//                                Animer animerX = new Animer();
//                                animerX.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerX.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));
                                animerX.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {
                                        rv.setTranslationX(value);
                                    }
                                });

//                                Animer animerY = new Animer();
//                                animerY.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerY.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));
                                animerY.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {
                                        rv.setTranslationY(value);
                                    }
                                });

//                                Animer animerIconX = new Animer();
//                                animerIconX.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerIconX.setSolver(Animer.springDroid(CloseStiffness,Math.max(0.01f,CloseDampingRatio-parallaxDamping)));
                                animerIconX.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        if(i == 0){
                                            store.setTranslationX(value);
                                        }
                                        if(i == 1){
                                            game.setTranslationX(value);
                                        }
                                        if(i == 18){
                                            wechat.setTranslationX(value);
                                        }
                                        if(i == 19){
                                            setting.setTranslationX(value);
                                        }

                                        if(i == 28){
                                            phone.setTranslationX(value);
                                        }
                                        if(i == 29){
                                            message.setTranslationX(value);
                                        }
                                        if(i == 30){
                                            browser.setTranslationX(value);
                                        }
                                        if(i == 31){
                                            camera.setTranslationX(value);
                                        }
                                    }
                                });

//                                Animer animerIconGraphs = new Animer();
//                                animerIconGraphs.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerIconGraphs.setSolver(Animer.springDroid(CloseStiffness,0.9f));
                                animerIconGraphs.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        if(i == 0){
                                            store.setScaleX(value);
                                            store.setScaleY(value);
                                        }
                                        if(i == 1){
                                            game.setScaleX(value);
                                            game.setScaleY(value);
                                        }
                                        if(i == 18){
                                            wechat.setScaleX(value);
                                            wechat.setScaleY(value);
                                        }
                                        if(i == 19){
                                            setting.setScaleX(value);
                                            setting.setScaleY(value);
                                        }

                                        if(i == 28){
                                            phone.setScaleX(value);
                                            phone.setScaleY(value);
                                        }
                                        if(i == 29){
                                            message.setScaleX(value);
                                            message.setScaleY(value);
                                        }
                                        if(i == 30){
                                            browser.setScaleX(value);
                                            browser.setScaleY(value);
                                        }
                                        if(i == 31){
                                            camera.setScaleX(value);
                                            camera.setScaleY(value);
                                        }
                                    }
                                });
                                animerIconGraphs.setCurrentValue(5);

//                                Animer animerIconY = new Animer();
//                                animerIconY.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerIconY.setSolver(Animer.springDroid(CloseStiffness,Math.max(0.01f,CloseDampingRatio-parallaxDamping)));
                                animerIconY.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        if(i == 0){
                                            store.setTranslationY(value);
                                        }
                                        if(i == 1){
                                            game.setTranslationY(value);
                                        }
                                        if(i == 18){
                                            wechat.setTranslationY(value);
                                        }

                                        if(i == 19){

                                            setting.setTranslationY(value);
                                        }

                                        if(i == 28){
                                            phone.setTranslationY(value);
                                        }
                                        if(i == 29){
                                            message.setTranslationY(value);
                                        }
                                        if(i == 30){
                                            browser.setTranslationY(value);
                                        }
                                        if(i == 31){
                                            camera.setTranslationY(value);
                                        }
                                    }
                                });

//                                Animer animerAlpha = new Animer();
//                                animerAlpha.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_ALPHA);
//                                animerAlpha.setSolver(Animer.springDroid(200,0.92f));
                                animerAlpha.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        for(int i=0;i<viewList.size();i++){
                                            if(viewList.get(i).getId() != view.getId()){
                                                viewList.get(i).setAlpha(value);
                                            }
                                        }

                                        findViewById(R.id.page_indicator).setAlpha(value);

                                    }
                                });


//                                Animer animerGridScale = new Animer();
//                                animerGridScale.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerGridScale.setSolver(Animer.springDroid(200,0.92f));
                                animerGridScale.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        for(int i=0;i<viewList.size();i++){
                                            if(viewList.get(i).getId() != view.getId()){
                                                viewList.get(i).setScaleX(value);
                                                viewList.get(i).setScaleY(value);
                                                viewList.get(i).setPivotX(540-viewList.get(i).getTranslationX());
                                                viewList.get(i).setPivotY(1170-viewList.get(i).getTranslationY());
                                            }
//                                            else{
//                                                viewList.get(i).setScaleX(1);
//                                                viewList.get(i).setScaleY(1);
//                                                viewList.get(i).setPivotX(viewList.get(i).getTranslationX()+156/2);
//                                                viewList.get(i).setPivotY(viewList.get(i).getTranslationY()+156/2);
//                                            }
                                        }
                                        findViewById(R.id.page_indicator).setScaleX(value);
                                        findViewById(R.id.page_indicator).setScaleY(value);
                                        findViewById(R.id.page_indicator).setPivotX(540-findViewById(R.id.page_indicator).getTranslationX());
                                        findViewById(R.id.page_indicator).setPivotY(1170-findViewById(R.id.page_indicator).getTranslationY());
                                    }
                                });

//                                Animer animerOpen = new Animer();
//                                animerOpen.setFrom(0);
//                                animerOpen.setTo(1);
//                                animerOpen.setSolver(Animer.springDroid(OpenStiffnes,OpenDampingRatio));
//                                animerOpen.setMinimumVisibleChange(0.002f);

                                // # Change
                                icon.setAlpha(0f);
                                if(i == 0){
                                    store.setAlpha(0f);
                                }
                                if(i == 1){
                                    game.setAlpha(0f);
                                }
                                if(i == 18){
                                    wechat.setAlpha(0f);
                                }

                                if(i == 19){
                                    setting.setAlpha(0f);
                                }

                                if(i == 28){
                                    phone.setAlpha(0f);
                                }
                                if(i == 29){
                                    message.setAlpha(0f);
                                }
                                if(i == 30){
                                    browser.setAlpha(0f);
                                }
                                if(i == 31){
                                    camera.setAlpha(0f);
                                }

                                animerOpen.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        // # Change
                                        // float wV = (float) AnimerUtil.mapValueFromRangeToRange(progress,0,1,156,1080);
                                        // float hV = (float) AnimerUtil.mapValueFromRangeToRange(progress,0,1,156,2340);
                                        // float hV2 = (float) AnimerUtil.mapValueFromRangeToRange(progress,0,1,156,1080);

                                        float wV = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,895,1080);
                                        float hV = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,1903,2340);
                                        float hV2 = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,895,1080);

                                        float maskAlpha = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0,0.5f,0,0.6f);
                                        findViewById(R.id.total_mask).setAlpha(maskAlpha);

                                        if(!rv.isOpened()){
                                            float alpha = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0.0f,0.25f,0,1);
                                            float alphaReverse = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0.0f,0.25f,1,0);
                                            app.setAlpha(alpha);
                                            icon.setAlpha(alphaReverse);
                                        }
                                        else{
                                            // # Change
                                            // float alpha = (float) AnimerUtil.mapClampedValueFromRangeToRange(progress,0.35,0.5,0,1);
                                            // float alphaReverse = (float) AnimerUtil.mapClampedValueFromRangeToRange(progress,0.35,0.5,1,0);
                                            float alpha = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0.0f,0.15f,0,1);

                                            // # Change
                                            // float alphaReverse = (float) AnimerUtil.mapClampedValueFromRangeToRange(progress,0.0,0.5,1,0);
                                            app.setAlpha(alpha);
                                            // icon.setAlpha(alphaReverse);
                                        }


                                        // ### Icon Scale Animation
                                        float scale = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,1,0.8f);
                                        animerGridScale.setCurrentValue(scale);
                                        float alpha = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,1,0);
                                        animerAlpha.setCurrentValue(alpha);



                                        float transX = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,(finalStartX + (index%4)*246)*0.2f,0);
                                        float transY = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,(finalStartY + (int)Math.ceil(index/4)*291f - bottomValue)*0.2f,0);


                                        app.getLayoutParams().width = (int)wV + (int) (wV - Math.floor(wV))*10;
                                        app.getLayoutParams().height = (int)hV + (int) (hV - Math.floor(hV))*10;
                                        app.requestLayout();

                                        icon.getLayoutParams().width = (int)wV + (int) (wV - Math.floor(wV))*10;
                                        icon.getLayoutParams().height = (int)hV2 + (int) (hV2 - Math.floor(hV2))*10;
                                        icon.requestLayout();

                                        // rv.setCornerRadiusWithoutInvalidate(radius);
                                        rv.getLayoutParams().width = (int)wV + (int) (wV - Math.floor(wV))*10;
                                        rv.getLayoutParams().height = (int)hV + (int) (hV - Math.floor(hV))*10;
                                        rv.setTranslationX(transX);
                                        rv.setTranslationY(transY);
                                        rv.requestLayout();


                                    }
                                });

//                                Animer animerClosed = new Animer();
//                                animerClosed.setFrom(0);
//                                animerClosed.setTo(1);
//                                animerClosed.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);
//                                animerClosed.setSolver(Animer.springDroid(CloseStiffness,CloseDampingRatio));
                                animerClosed.setUpdateListener(new Animer.UpdateListener() {
                                    @Override
                                    public void onUpdate(float value, float velocity, float progress) {

                                        float wV = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,rv.getLayoutParams().width,156);
                                        float hV = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,rv.getLayoutParams().height,156);
                                        float hV2 = (float) AnUtil.mapValueFromRangeToRange(progress,0,1,icon.getLayoutParams().height,156);
                                        float alpha = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0.5f,0.65f,1,0);
                                        float alphaReverse = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0.5f,0.65f,0,1);

                                        float maskAlpha = (float) AnUtil.mapClampedValueFromRangeToRange(progress,0,1,findViewById(R.id.total_mask).getAlpha(),0);
                                        findViewById(R.id.total_mask).setAlpha(maskAlpha);

                                        app.getLayoutParams().width = (int)wV  + (int) (wV - Math.floor(wV))*10;
                                        app.getLayoutParams().height = (int)hV + (int) (hV - Math.floor(hV))*10;
                                        app.requestLayout();
                                        app.setAlpha(alpha);

                                        icon.getLayoutParams().width = (int)wV  + (int) (wV - Math.floor(wV))*10;
                                        icon.getLayoutParams().height = (int)hV2 + (int) (hV2 - Math.floor(hV2))*10;
                                        icon.requestLayout();
                                        icon.setAlpha(alphaReverse);


                                        rv.getLayoutParams().width = (int)wV  + (int) (wV - Math.floor(wV))*10;
                                        rv.getLayoutParams().height = (int)hV + (int) (hV - Math.floor(hV))*10;
                                        rv.requestLayout();


                                        if(i == 0){
                                            store.setAlpha(alphaReverse);
                                        }
                                        if(i == 1){
                                            game.setAlpha(alphaReverse);
                                        }

                                        if(i == 18){
                                            wechat.setAlpha(alphaReverse);
                                        }

                                        if(i == 19){
                                            setting.setAlpha(alphaReverse);
                                        }

                                        if(i == 28){
                                            phone.setAlpha(alphaReverse);
                                        }
                                        if(i == 29){
                                            message.setAlpha(alphaReverse);
                                        }
                                        if(i == 30){
                                            browser.setAlpha(alphaReverse);
                                        }
                                        if(i == 31){
                                            camera.setAlpha(alphaReverse);
                                        }

                                    }
                                });

                                animerClosed.setEndListener(new Animer.EndListener() {
                                    @Override
                                    public void onEnd(float value, float velocity, boolean canceled) {
                                        rv.setOpened(false);
                                        rv.setTranslationZ(0);
                                        rv.setOnTouchListener(null);
                                        if(mTouchListener !=null){
                                            rv.setOnTouchListener(mTouchListener);
                                        }
                                    }
                                });



                                if(!rv.isOpened()) {

                                    rv.setOpened(true);
                                    animerOpen.setCurrentValue(0);
                                    animerOpen.setEndvalue(1);
                                    rv.setTranslationZ(100);
                                    rv.setOnClickListener(null);


                                    rv.setOnTouchListener(new View.OnTouchListener() {

                                        float startX = 0, startY = 0, transX = 0, transY = 0;
                                        float velocityX = 0, velocityY = 0;
                                        float changeValX = 0, changeValY = 0;

                                        float bottomArea = 200;
                                        float sideArea = 940;


                                        @Override
                                        public boolean onTouch(View view, MotionEvent motionEvent) {

                                            switch (motionEvent.getAction()) {
                                                case MotionEvent.ACTION_DOWN:

                                                    bezierDrawingView.startRandomAnimation();
                                                    mSpringY.setCurrentValue(motionEvent.getRawY());
                                                    startX = motionEvent.getRawX();
                                                    startY = motionEvent.getRawY();
                                                    dampingMove = 0;
                                                    isVibrate = false;

                                                    if (mVelocityTracker == null) {
                                                        // Retrieve a new VelocityTracker object to watch the velocity of a motion.
                                                        mVelocityTracker = VelocityTracker.obtain();
                                                    } else {
                                                        // Reset the velocity tracker back to its initial state.
                                                        mVelocityTracker.clear();
                                                    }
                                                    break;
                                                case MotionEvent.ACTION_MOVE:

                                                    changeValX = motionEvent.getRawX() - startX;
                                                    changeValY = motionEvent.getRawY() - startY;
                                                    transX = motionEvent.getRawX();
                                                    transY = motionEvent.getRawY();

                                                    if (startY > 2340 - bottomArea) {

                                                        float dampingMove = (float) -(1 - 1 / Math.exp(-(transY - startY) / 1200 * 0.66f)) * 1170;

                                                        float wV = (float) AnUtil.mapValueFromRangeToRange(dampingMove, 0, -700, 1080, 540);
                                                        float hV = (float) AnUtil.mapValueFromRangeToRange(dampingMove, 0, -700, 2340, 1170);
                                                        float hV2 = (float) AnUtil.mapValueFromRangeToRange(dampingMove, 0, -700, 1080, 540);


                                                        float maskAlpha = (float) AnUtil.mapClampedValueFromRangeToRange(dampingMove, 0, -700, 0.6f, 0);
                                                        findViewById(R.id.total_mask).setAlpha(maskAlpha);

                                                        app.getLayoutParams().width = (int) wV;
                                                        app.getLayoutParams().height = (int) hV;
                                                        app.requestLayout();

                                                        icon.getLayoutParams().width = (int) wV;
                                                        icon.getLayoutParams().height = (int) hV2;
                                                        icon.requestLayout();

                                                        rv.getLayoutParams().width = (int) wV;
                                                        rv.getLayoutParams().height = (int) hV;
                                                        rv.requestLayout();

                                                        // ### Icon scale Animation
                                                        float scale = (float) AnUtil.mapValueFromRangeToRange(dampingMove,0,-700,0.8f,0.85f);
                                                        animerGridScale.setCurrentValue(scale);

                                                        animerX.setCurrentValue(transX - startX + ((1 - wV / 1080) * 540));
                                                        animerY.setCurrentValue(dampingMove + ((1 - wV / 1080) * 2340));
                                                        float iconGraphScale = (float) AnUtil.mapValueFromRangeToRange(dampingMove,0,-700,2.5f,1.5f);
                                                        animerIconGraphs.setCurrentValue(iconGraphScale);


                                                    } else if (startY > 2340 - bottomArea - sideArea) {
                                                        if (startX < 420 && changeValX > 0) {


                                                            findViewById(R.id.bezier_layout).setRotation(0f);
                                                            dampingMove = (float) (1 - 1 / Math.exp(changeValX / 200)) * 120;
                                                            updateBezierView(new PointF(dampingMove, motionEvent.getRawY()));

                                                        } else if (startX > 660 && changeValX < 0) {
                                                            findViewById(R.id.bezier_layout).setRotation(180);
                                                            dampingMove = (float) (1 - 1 / Math.exp(-changeValX / 200)) * 120;
                                                            updateBezierView(new PointF(dampingMove, 2340 - motionEvent.getRawY()));
                                                        }
                                                    }


                                                    mVelocityTracker.addMovement(motionEvent);
                                                    mVelocityTracker.computeCurrentVelocity(1000);
                                                    // Log velocity of pixels per second
                                                    velocityX = mVelocityTracker.getXVelocity(0);
                                                    velocityY = mVelocityTracker.getYVelocity(0);

                                                    break;
                                                case MotionEvent.ACTION_UP:

                                                    if (startY > 2340 - bottomArea) {
                                                        cancelBezierState(motionEvent, startX);
                                                        finalX = finalStartX + (index % 4) * 246;
                                                        finalY = finalStartY + (int) Math.ceil(index / 4) * 291 - bottomValue;
                                                        animerX.setVelocity(velocityX);
                                                        animerX.setEndvalue(finalX);
                                                        animerY.setVelocity(velocityY);
                                                        animerY.setEndvalue(finalY);
                                                        animerGridScale.setEndvalue(1);
                                                        animerAlpha.setEndvalue(1);
                                                        animerIconGraphs.setVelocity( (float) Math.sqrt(Math.pow(velocityX,2)+Math.pow(velocityY,2))/46);
                                                        animerIconGraphs.setEndvalue(1);

                                                        animerClosed.start();
                                                    } else if (startY > 2340 - bottomArea - sideArea & Math.abs(changeValX) > 100) {
                                                        cancelBezierState(motionEvent, startX);
                                                        finalX = finalStartX + (index % 4) * 246;
                                                        finalY = finalStartY + (int) Math.ceil(index / 4) * 291 - bottomValue;
                                                        animerX.setVelocity(velocityX);
                                                        animerX.setEndvalue(finalX);
                                                        animerY.setVelocity(velocityY);
                                                        animerY.setEndvalue(finalY);
                                                        animerGridScale.setEndvalue(1);
                                                        animerAlpha.setEndvalue(1);
                                                        animerIconGraphs.setVelocity( (float) Math.sqrt(Math.pow(velocityX,2)+Math.pow(velocityY,2))/46);
                                                        animerIconGraphs.setEndvalue(1);

                                                        animerClosed.start();
                                                    }


                                                    break;
                                                case MotionEvent.ACTION_CANCEL:

                                                    if (startY > 2340 - bottomArea) {
                                                        cancelBezierState(motionEvent, startX);
                                                        finalX = finalStartX + (index % 4) * 246;
                                                        finalY = finalStartY + (int) Math.ceil(index / 4) * 291 - bottomValue;
                                                        animerX.setVelocity(velocityX);
                                                        animerX.setEndvalue(finalX);
                                                        animerY.setVelocity(velocityY);
                                                        animerY.setEndvalue(finalY);
                                                        animerGridScale.setEndvalue(1);
                                                        animerAlpha.setEndvalue(1);
                                                        animerIconGraphs.setVelocity( (float) Math.sqrt(Math.pow(velocityX,2)+Math.pow(velocityY,2))/46);
                                                        animerIconGraphs.setEndvalue(1);

                                                        animerClosed.start();
                                                    } else if (startY > 2340 - bottomArea - sideArea & Math.abs(changeValX) > 100) {
                                                        cancelBezierState(motionEvent, startX);
                                                        finalX = finalStartX + (index % 4) * 246;
                                                        finalY = finalStartY + (int) Math.ceil(index / 4) * 291 - bottomValue;
                                                        animerX.setVelocity(velocityX);
                                                        animerX.setEndvalue(finalX);
                                                        animerY.setVelocity(velocityY);
                                                        animerY.setEndvalue(finalY);
                                                        animerGridScale.setEndvalue(1);
                                                        animerAlpha.setEndvalue(1);
                                                        animerIconGraphs.setVelocity( (float) Math.sqrt(Math.pow(velocityX,2)+Math.pow(velocityY,2))/46);
                                                        animerIconGraphs.setEndvalue(1);

                                                        animerClosed.start();
                                                    }
                                                    break;
                                            }
                                            return true;
                                        }
                                    });
                                }
                            }
                        },100);

                        break;
                    case MotionEvent.ACTION_CANCEL:

                        break;
                }
                return true;
            }
        };

        rv.setOnTouchListener(touchContainer);

    }

    private void initBezierView(){
        bezierDrawingView = findViewById(R.id.bezier_view);
        bezierDrawingView.setSetEffectIsClamped(true);
    }






    private void updateBezierView(PointF point){
        mSpringX.setEndValue(point.x);
        mSpringY.setCurrentValue(point.y);
    }
    private void cancelBezierState(MotionEvent event,float starX){
        bezierDrawingView.stopRandomAnimation();
        isVibrate = false;

        if(starX < 420){
            updateBezierView(new PointF(-20,event.getRawY()));

        }
        else if(starX>660){
            updateBezierView(new PointF(-20,2340-event.getRawY()));
        }


    }

    private void setSpringSystem() {
        mSpringSystem = SpringSystem.create();
        mSpringX = mSpringSystem.createSpring();
        mSpringX.setSpringConfig(mconfig);
        mSpringX.addListener(new SimpleSpringListener() {
            @Override
            public void onSpringUpdate(Spring mSpring) {
                float progressVal = (float) mSpring.getCurrentValue();
                movePointF.x = progressVal;
                bezierDrawingView.setGesturePoint(movePointF);
                findViewById(R.id.arrow).setTranslationX(progressVal -46-33-12);
            }
        });

        mSpringY = mSpringSystem.createSpring();
        mSpringY.setSpringConfig(mconfig);
        mSpringY.addListener(new SimpleSpringListener() {
            @Override
            public void onSpringUpdate(Spring mSpring) {
                float progressVal = (float) mSpring.getCurrentValue();
                movePointF.y = progressVal;
                bezierDrawingView.setGesturePoint(movePointF);
                findViewById(R.id.arrow).setTranslationY(progressVal - 28);
            }
        });
    }

    private void deleteBars(){
        //Delete Title Bar
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Delete Action Bar
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();
    }

    private boolean isHitArea = true;
    private boolean isClosed = false;
    private BubbleSeekBar mSeek1,mSeek2,mSeek3,mSeek4;

    private void setRangeSeekbar(){
        mSeek1 = findViewById(R.id.o_1);
        mSeek2 = findViewById(R.id.o_2);
        mSeek3 = findViewById(R.id.c_1);
        mSeek4 = findViewById(R.id.c_2);

        mSeek1.setProgress(OpenStiffnes);
        mSeek2.setProgress(OpenDampingRatio);
        mSeek3.setProgress(CloseStiffness);
        mSeek4.setProgress(CloseDampingRatio);


        mSeek1.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                OpenStiffnes = progressFloat;
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

        mSeek2.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                Log.e("Progress",String.valueOf(progressFloat));
                OpenDampingRatio = progressFloat;
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

        mSeek3.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                CloseStiffness = progressFloat;
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

        mSeek4.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                Log.e("Progress",String.valueOf(progressFloat));
                CloseDampingRatio = progressFloat;
            }

            @Override
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });



    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)){
            if(!isClosed){
                findViewById(R.id.borad).setVisibility(View.INVISIBLE);
            }
            else{

                findViewById(R.id.borad).setVisibility(View.VISIBLE);
            }

            isClosed = !isClosed;
        }

        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP)){
            if(!isHitArea){
                findViewById(R.id.hit_area).setVisibility(View.VISIBLE);
            }
            else{
                findViewById(R.id.hit_area).setVisibility(View.INVISIBLE);
            }

            isHitArea = !isHitArea;
        }

        return true;
    }
    
}

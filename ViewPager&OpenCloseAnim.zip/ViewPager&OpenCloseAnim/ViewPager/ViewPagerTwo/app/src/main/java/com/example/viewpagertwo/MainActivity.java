package com.example.viewpagertwo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.martinrgb.animer.core.Animer;
import com.martinrgb.animer.core.solver.SpringSolver;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // ### Fake Data
    private static final int[] IMAGE = {
            R.drawable.icon_0,
            R.drawable.icon_1,
            R.drawable.icon_2,
            R.drawable.icon_3,
            R.drawable.icon_4};

    private static ImageView iv0,iv1,iv2,iv3,iv4;
    private static final ImageView[] ImageViews = {iv0,iv1,iv2,iv3,iv4};

    private int currentIndex = 0;
    private int prevIndex = 0;
    private RelativeLayout fakeContainer;

    // ### Animator
    private static VelocityTracker mVelocityTracker;
    private float velocityX;
    private Animer scrollAnimer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Delete Title Bar
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Delete Action Bar
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        fakeContainer = findViewById(R.id.fake_container);
        createImageList();

        scrollAnimer = new Animer();
        scrollAnimer.setSolver(new SpringSolver(500,0.99f));
        scrollAnimer.setUpdateListener(new Animer.UpdateListener() {
            @Override
            public void onUpdate(float value, float velocity, float progress) {
                setGroupTransX(value);
            }
        });
        scrollAnimer.setMinimumVisibleChange(0.5f);
        scrollAnimer.setCurrentValue(0);

        fakeContainer.setOnTouchListener(new View.OnTouchListener() {
            float startX,startY,transX;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX();

                        if(mVelocityTracker == null) {
                            mVelocityTracker = VelocityTracker.obtain();
                        }
                        else {
                            mVelocityTracker.clear();
                        }
                        mVelocityTracker.addMovement(event);
                        prevIndex = currentIndex;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        mVelocityTracker.addMovement(event);
                        mVelocityTracker.computeCurrentVelocity(1000);

                        transX = event.getRawX() - startX;

                        // Simple Edge Damping Effect
                        if((prevIndex == 0 && transX>0)|| (prevIndex == (IMAGE.length-1) && transX<0)){
                            scrollAnimer.setCurrentValue(-prevIndex*1080 + transX/4);
                        }
                        else{
                            scrollAnimer.setCurrentValue(-prevIndex*1080 + transX);
                        }

                        velocityX =  mVelocityTracker.getXVelocity();
                        break;
                    case MotionEvent.ACTION_UP:
                        if(Math.abs(transX) > 200){
                            if(transX >0){
                                currentIndex--;
                            }
                            else{
                                currentIndex++;
                            }

                        }
                        currentIndex = clamp(currentIndex,0,IMAGE.length-1);
                        scrollAnimer.setVelocity(velocityX);
                        scrollAnimer.setEndvalue(-currentIndex*1080);

                        break;
                    case MotionEvent.ACTION_CANCEL:
                        break;
                }
                return true;
            }
        });
    }

    public static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
    public static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }

    private void setGroupTransX(float translationX){
        for (int i=0;i<IMAGE.length;i++){
            ImageViews[i].setTranslationX(i*1080 + translationX);
        }
    }

    private void createImageList() {
        for (int i=0;i<IMAGE.length;i++){

            ImageViews[i] = new ImageView(getApplicationContext());
            ImageViews[i].setBackgroundResource(IMAGE[i]);
            RelativeLayout.LayoutParams mBGLayout = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            mBGLayout.setMargins(0,0,0,0);
            ImageViews[i].setLayoutParams(mBGLayout);
            ImageViews[i].setTranslationX(i*1080);
            fakeContainer.addView(ImageViews[i]);
        }
    }
}

package com.example.newviewpager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import me.everything.android.ui.overscroll.IOverScrollDecor;
import me.everything.android.ui.overscroll.IOverScrollUpdateListener;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class MainActivity extends AppCompatActivity {

    private static final int[] IMAGE = {
            R.drawable.icon_0,
            R.drawable.icon_1,
            R.drawable.icon_2,
            R.drawable.icon_3,
            R.drawable.icon_4};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Delete Title Bar
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Delete Action Bar
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        initViews();
    }

    private static ViewPager pager;
    private VelocityTracker mVelocityTracker;
    private float velocityX;
    private float transX,startX;
    private float initPosition;


    @SuppressLint("ClickableViewAccessibility")
    private void initViews() {
        FakeAdaper adapter = new FakeAdaper();
        adapter.setData(createPageList());
        pager = findViewById(R.id.view_pager);
        pager.setAdapter(adapter);

        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //Log.e("pos2",String.valueOf(position));
            }

            @Override
            public void onPageSelected(int position) {
                Log.e("pos",String.valueOf(position));
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        pager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if(mVelocityTracker == null) {
                            mVelocityTracker = VelocityTracker.obtain();
                        }
                        else {
                            mVelocityTracker.clear();
                        }
                        mVelocityTracker.addMovement(event);
                        velocityX = 0;
                        startX = event.getRawX();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        mVelocityTracker.addMovement(event);
                        mVelocityTracker.computeCurrentVelocity(1000);
                        velocityX =  mVelocityTracker.getXVelocity(0);
                        transX = event.getRawX() - startX;

                        initPosition = Math.abs(transX);

                        Log.e("transX in MOVE",String.valueOf(transX));
                        break;
                    case MotionEvent.ACTION_UP:
                        Log.e("transX in UP",String.valueOf(transX));
                        Log.e("velocity X in UP",String.valueOf(velocityX));
                        setupScrollerAnimator(velocityX,initPosition);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        setupScrollerAnimator(velocityX,initPosition);
                        break;
                }
                return false;
            }
        });



    }

    private void setupScrollerAnimator(float initialVelocity,float initialPosition){
        try {
            Class clazz=Class.forName("androidx.viewpager.widget.ViewPager");
            Field f=clazz.getDeclaredField("mScroller");


            float initToFinalTrans = getPagerTransition(initialVelocity,initialPosition);


            // ### OriginalInterpolator
//            int originalDuration = (int) getDurationByOrginalMethod(initialVelocity,initToFinalTrans);
//            float mDuration = Math.min(600,Math.max(400,originalDuration));
//
//            final DefaultInterpolator mTranslationXInterpolator  = new DefaultInterpolator(3);
//
//            float factor = 0.6f -  (mDuration-400)/200   * 0.4f;
//
//            mTranslationXInterpolator.setpowFactor(factor);
//
//
//            FixedSpeedScroller fixedSpeedScroller=new FixedSpeedScroller(this,mTranslationXInterpolator);
//
//            Log.e("Orig",String.valueOf(originalDuration));
//            Log.e("mDuration",String.valueOf(mDuration));
//            fixedSpeedScroller.setmDuration((int)mDuration);


            // ### CustomMocosSpringInterpolator
//            final CustomMocosSpringInterpolator mTranslationXInterpolator = new CustomMocosSpringInterpolator(30,10);
//            mTranslationXInterpolator.setInitialVelocity(Math.abs(initialVelocity)/ initToFinalTrans);
//            FixedSpeedScroller fixedSpeedScroller=new FixedSpeedScroller(this,mTranslationXInterpolator);
//            fixedSpeedScroller.setmDuration((int)(1000 * mTranslationXInterpolator.getDesiredDuration()));

            // ### AndroidSpringInterpolator
            int originalDuration = (int) getDurationByOrginalMethod(initialVelocity,initToFinalTrans);
            float mDuration = Math.min(600,Math.max(420,originalDuration/2));

            final float density = getApplicationContext().getResources().getDisplayMetrics().density;
            final float MIN_VELOCITY = 400;
            final float MinVelocity = MIN_VELOCITY * density;

            float stiffnes = 300;


            if(Math.abs(initialVelocity/5) < MinVelocity){
                stiffnes = 200;
            }
            Log.e("VS",String.valueOf(Math.abs(initialVelocity/5.)));
            Log.e("MIN_VELOCITY",String.valueOf(MinVelocity));
            Log.e("is True",String.valueOf(Math.abs(initialVelocity/5) < MinVelocity));
            Log.e("stiffnes",String.valueOf(stiffnes));

            final AndroidSpringInterpolator mTranslationXInterpolator  = new AndroidSpringInterpolator(stiffnes,0.9999f,Math.abs(initialVelocity/5.f) /initToFinalTrans,mDuration);
            FixedSpeedScroller fixedSpeedScroller=new FixedSpeedScroller(this,mTranslationXInterpolator);
            Log.e("Orig",String.valueOf(originalDuration));
            Log.e("mDuration",String.valueOf(mDuration));
            fixedSpeedScroller.setmDuration((int)mDuration);

            // ### ViscousFluidInterpolator
//            final ViscousFluidInterpolator mTranslationXInterpolator  = new ViscousFluidInterpolator(6);
//            FixedSpeedScroller fixedSpeedScroller=new FixedSpeedScroller(this,mTranslationXInterpolator);
//            int originalDuration = (int) getDurationByOrginalMethod(initialVelocity,initToFinalTrans);
//            float mDuration = Math.min(500,Math.max(300,originalDuration/2));
//            fixedSpeedScroller.setmDuration((int)mDuration);

            f.setAccessible(true);
            f.set(pager,fixedSpeedScroller);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private float getPagerTransition(float initialVelocity,float initialPosition){
        final float density = getApplicationContext().getResources().getDisplayMetrics().density;
        final float screenWidth = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
        final float MIN_VELOCITY = 400;
        final float MinVelocity = MIN_VELOCITY * density;

        float value = (Math.abs(initialVelocity)> MinVelocity)? screenWidth - initialPosition:initialPosition;
        return value;
    }

    private float getDurationByOrginalMethod(float initialVelocity,float trans){
        final float density = getApplicationContext().getResources().getDisplayMetrics().density;
        final float screenWidth = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
        final float halfWidth = screenWidth/2;
        final float currentPageWidht = screenWidth;
        float distanceRatio = Math.min(1,trans/screenWidth);
        float distance = halfWidth + halfWidth * distanceInfluenceForSnapDuration(distanceRatio);
        final float MIN_VELOCITY = 400;
        final float MinVelocity = MIN_VELOCITY * density;

        float velocity = Math.abs(initialVelocity);
        velocity = Math.max(MIN_VELOCITY,velocity);
        float mDuration  = 4 * Math.round(1000 * Math.abs(distance / velocity));
        return mDuration;
    }

    float distanceInfluenceForSnapDuration(float f) {
        f -= 0.5f; // center the values about 0.
        f *= 0.3f * (float) Math.PI / 2.0f;
        return (float) Math.sin(f);
    }

    private List<RelativeLayout> createPageList() {
        List<RelativeLayout> pageList = new ArrayList<>();
        for (int i=0;i<IMAGE.length;i++){

            RelativeLayout layout = new RelativeLayout(this);

            ImageView bg = new ImageView(getApplicationContext());
            bg.setBackgroundResource(IMAGE[i]);
            RelativeLayout.LayoutParams mBGLayout = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            mBGLayout.setMargins(0,0,0,0);
            bg.setLayoutParams(mBGLayout);
            layout.addView(bg);
            pageList.add(layout);
        }
        return pageList;
    }


}

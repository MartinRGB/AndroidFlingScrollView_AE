package com.example.newviewpager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class FakeAdaper extends PagerAdapter {

    private List<RelativeLayout> layoutList;

    FakeAdaper() {
        this.layoutList = new ArrayList<>();
    }

    @Override
    public Object instantiateItem(ViewGroup collection, int position) {
        RelativeLayout relativeLayout = layoutList.get(position);
        collection.addView(relativeLayout);
        return relativeLayout;
    }

    @Override
    public void destroyItem(ViewGroup collection, int position, Object view) {
        collection.removeView((View) view);
    }

    @Override
    public int getCount() {
        return layoutList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    void setData(@Nullable List<RelativeLayout> list) {
        this.layoutList.clear();
        if (list != null && !list.isEmpty()) {
            this.layoutList.addAll(list);
        }

        notifyDataSetChanged();
    }

    @NonNull
    List<RelativeLayout> getData() {
        if (layoutList == null) {
            layoutList = new ArrayList<>();
        }

        return layoutList;
    }
}

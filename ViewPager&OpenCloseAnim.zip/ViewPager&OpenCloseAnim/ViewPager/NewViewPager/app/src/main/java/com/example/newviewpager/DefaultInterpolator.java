package com.example.newviewpager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Scroller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import me.everything.android.ui.overscroll.IOverScrollDecor;
import me.everything.android.ui.overscroll.IOverScrollUpdateListener;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

// Interpolator Version of Android's SpringAnimation

import android.view.animation.Interpolator;

public class DefaultInterpolator implements Interpolator{

    //Parameters

    private int powNumber = 5;

    private float powFactor = 0.6f;
    public DefaultInterpolator(int powNumber) {

        this.powNumber = powNumber;
    }

    public void setpowFactor(float factor){
        this.powFactor = factor;
    }

    @Override
    public float getInterpolation(float t) {

//        return (float)Math.pow(t-1,powNumber) + 1.0f;
        //return  1.0f - (float)Math.pow(Math.E,5*-t);

//        if (t >= 1) {
//            return 1;
//        }
        return (float)Math.pow(1.0f + (float)Math.sin(3.15/2.*Math.pow((t-1),5)),powFactor);


    }
}